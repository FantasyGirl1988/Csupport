<?php

namespace ChatSupport\Drama_Lvl1;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;

class Main extends PluginBase {

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool{
        if($cmd->getName() === "supporter"){
            if ($sender->hasPermission("chatsupport.supporter.cmd")) {
				if(isset($args[0])) {
                    $name = $sender->getName();
                    $msg = implode(" ", $args);
                    $sender->sendMessage("§4Gamer§r§lHub §r§8»  §7Du -> §aSupporter: §e" . $msg);
                    $sender->sendMessage("§4Gamer§r§lHub §r§8» §aDu hast die Nachricht §6" . $msg . " §azu einem §eSupporter §agesendet!");
                    foreach($this->getServer()->getOnlinePlayers() as $player) {
                        if ($player->hasPermission("chatsupport.supporter.see")) {
                            $player->sendMessage("§4Gamer§r§lHub §r§8»  §7$name -> §aSupporter: §e" . $msg);
						}
                    }
                } else {
					$sender->sendMessage("§4Gamer§r§lHub §r§8» §cBenutze: §a/supporter <nachricht>!");
				}
            } else if($sender->hasPermission("chatsupport.supporter.cmd")) {
				$sender->sendMessage("§4Gamer§r§lHub §r§8» §cDu hast keine Rechte für diesen Command!");
			}
		}
        if($cmd->getName() === "moderator"){
            if ($sender->hasPermission("chatsupport.moderator.cmd")) {
				if(isset($args[0])) {
			        $name = $sender->getName();
                    $msg = implode(" ", $args);
                    $sender->sendMessage("§4Gamer§r§lHub §r§8» §7Du -> §cModerator: §e" . $msg);
                    $sender->sendMessage("§4Gamer§r§lHub §r§8» §aDu hast eine die Nachricht §6" . $msg . " §azu einem §cModerator §agesendet!");
                    foreach($this->getServer()->getOnlinePlayers() as $player) {
                        if ($player->hasPermission("chatsupport.moderator.see")) {
                            $player->sendMessage("§4Gamer§r§lHub §r§8» §7$name -> §cModerator: §e" . $msg);
						}
                    }
                } else {
					$sender->sendMessage("§4Gamer§r§lHub §r§8» §cBenutze: §a/moderator <nachricht>");
				}
            } else if($sender->hasPermission("chatsupport.moderator.cmd")) {
				$sender->sendMessage("§4Gamer§r§lHub §r§8» §cDu hast keine Rechte für diesen Command!");
			}
		}
        if($cmd->getName() === "admin"){
            if ($sender->hasPermission("chatsupport.admin.cmd")) {
				if(isset($args[0])) {
			        $name = $sender->getName();
                    $msg = implode(" ", $args);
                    $sender->sendMessage("§4Gamer§r§lHub §r§8»  §7Du -> §4Admin: §e" . $msg);
                    $sender->sendMessage("§4Gamer§r§lHub §r§8» §aDu hast die Nachricht §6" . $msg . " zu einem §4Admin §agesendet!");
                    foreach($this->getServer()->getOnlinePlayers() as $player) {
                        if ($player->hasPermission("chatsupport.admin.see")) {
                           $player->sendMessage("§4Gamer§r§lHub §r§8»  §7$name -> §4Admin: §e" . $msg);
						}
                    }
                } else {
					$sender->sendMessage("§4Gamer§r§lHub §r§8»  §cBenutze: §a/admin <nachricht>");
				}
            } else if($sender->hasPermission("chatsupport.admin.cmd")) {
				$sender->sendMessage("§4Gamer§r§lHub §r§8» §cDu hast keine Rechte für diesen Command!");
			}
		}
        if($cmd->getName() === "chatsupport"){
            if ($sender->hasPermission("chatsupport.cmd")) {
                    $sender->sendMessage("§4Gamer§r§lHub §r§8»  §aHilfe bei ChatSupport");
                    $sender->sendMessage("§a/supporter §7- §eKontaktiere ein Supporter");
                    $sender->sendMessage("§a/moderator §7- §eKontaktiere ein Moderator");
                    $sender->sendMessage("§a/admin §7- §eKontaktiere ein Admin");
                    $sender->sendMessage("§a/chatsupport §7- §eInfos über ChatSupport");
                    $sender->sendMessage("§aDises Plugin wurde erstellet von §6FantasyGirl1988§a!");
            } else {
				$sender->sendMessage("§4Gamer§r§lHub §r§8» §cDu hast keine Rechte für diesen Command!");
			}
        }
	return true;
    }
}